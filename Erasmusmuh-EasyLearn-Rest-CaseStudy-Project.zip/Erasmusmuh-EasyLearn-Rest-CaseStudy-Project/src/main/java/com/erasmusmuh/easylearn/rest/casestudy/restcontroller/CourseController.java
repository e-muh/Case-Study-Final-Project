package com.erasmusmuh.easylearn.rest.casestudy.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erasmusmuh.easylearn.rest.casestudy.entity.Course;
import com.erasmusmuh.easylearn.rest.casestudy.service.CourseService;



@RestController
@RequestMapping("/course")
public class CourseController {
	//add courseService dependency
	@Autowired
	private CourseService courseService;
	

	
	@GetMapping("/listCourses")
	public List<Course> listCourses(){
		// get courses from the service
		return  courseService.getCourses();
					
	}
	
	@GetMapping("/courseById/{courseId}")
	public Course getCustomer(@PathVariable int courseId) throws Exception {
		
		Course theCourse = courseService.getCourseById(courseId);
		
		if (theCourse == null) {
			throw new Exception("Course id not found - " + courseId);
		}
		
		return theCourse;
	}
	
	// add mapping for POST /course  - to add new course
	@PostMapping("/saveCourse")
	public Course saveCourse(@RequestBody Course theCourse) {
		
		// also just in case the pass an id in JSON ... set id to 0
		// this is force a save of new item ... instead of update
				
			theCourse.setCourseId(0);
				
			courseService.createCourse(theCourse);
				
			return theCourse;
		
	}
	
	// add mapping for PUT /course - to update existing course, change Instructor Name, return the updated course
	
	@PutMapping("/updateCourse/{courseId}/{courseInstructor}")
	public Course ChangeCourseDetails(@PathVariable int courseId, @PathVariable String courseInstructor) {
		
		//update course
		courseService.updateCourse(courseId, courseInstructor);
			
		return courseService.getCourseById(courseId);
			
		}
	
	// add mapping for DELETE /course/{courseId} - to delete course
	@DeleteMapping("/deleteCourseById/{courseId}")
	public String removeCourse(@PathVariable int courseId) throws Exception {
		
		Course theCourse = courseService.getCourseById(courseId);
		
		// throw exception if null
		
		if (theCourse == null) {
			
			throw new Exception("CourseId not found - " + courseId);
			}
			
		// delete the course
		courseService.deleteCourse(courseId);
				
		return "Deleted courseId - " + courseId;
			
		}
}

