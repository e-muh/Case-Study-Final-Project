package com.erasmusmuh.easylearn.rest.casestudy.dao;

import java.util.List;

import com.erasmusmuh.easylearn.rest.casestudy.entity.Course;


public interface CourseDAO {
	
	public List<Course> getAllCourses();
	
	public Course getCourseById(int courseId);
	
	//update courseInstructor
	public void updateCourse(int courseId, String courseInstructor);
	
	public void deleteCourse(int courseId);

	public void createCourse(Course course);

}
