package com.erasmusmuh.easylearn.rest.casestudy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name= "course")
public class Course {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column (name= "courseId")
	private int courseId;
	@Column (name= "courseName")
	private String courseName;
	@Column (name= "courseInstructor")
	private String courseInstructor;
	
	//constructors
	public Course() {}
	
	public Course(int courseId, String courseName, String courseInstructor) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.courseInstructor = courseInstructor;
	}

	//getters and setters
	
	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseInstructor() {
		return courseInstructor;
	}

	public void setCourseInstructor(String courseInstructor) {
		this.courseInstructor = courseInstructor;
	}


	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName + ", courseInstructor=" + courseInstructor
				+ "]";
	}


}
