package com.erasmusmuh.easylearn.rest.casestudy.service;

import java.util.List;

import com.erasmusmuh.easylearn.rest.casestudy.entity.Course;


public interface CourseService {
	
	public List<Course> getCourses();
	
	public Course getCourseById(int courseId);
	
	//update courseInstructor
	public void updateCourse(int courseId, String courseInstructor);
	
	public void deleteCourse(int courseId);

	public void createCourse(Course course);


}
