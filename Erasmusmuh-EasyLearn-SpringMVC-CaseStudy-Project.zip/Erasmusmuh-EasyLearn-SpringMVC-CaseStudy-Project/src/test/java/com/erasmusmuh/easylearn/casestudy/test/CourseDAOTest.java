package com.erasmusmuh.easylearn.casestudy.test;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import com.erasmusmuh.easylearn.casestudy.dao.CourseDAO;
import com.erasmusmuh.easylearn.casestudy.dao.CourseDAOImpli;
import com.erasmusmuh.easylearn.casestudy.entity.Course;

import junit.framework.Assert;

public class CourseDAOTest {
	
//	@Autowired
//	CourseDAO courseDAO;
	
	public CourseDAO courseDAO = null;

	
	@Before
	public void setUp() {
		
		courseDAO = new CourseDAOImpli();
		
		System.out.println(" DAO Testing Started!");
		
	}
	
	//test list courses method. test for list size
	
	@Test
	public void testGetAllCourses() {
		//When
		int numberOfCourse = 14; //max courseId on db
		
		//During
		List<Course> courses = courseDAO.getAllCourses();
		//find the size of the list
		int coursesSize = courses.size();
		
		//Then
		Assert.assertEquals(numberOfCourse, coursesSize);	
		
//		//you can also check if courseSize is > 1, for a list return
//		Assert.assertTrue(coursesSize > 1);
	}
	
	//test for getcoursr by id
	@Test
	public void testGetCourseById(){
		//When
		int courseId = 1;
		//create db course with id = 1
		Course course = new Course(1, "English", "Anderea Scamaden" );
		//Then, called get course by id method
		Course courseById = courseDAO.getCourseById(courseId);
		
		if(courseById != null) {
			
			Assert.assertEquals(course, courseById);
		}
		else
			Assert.assertNull("courseById not found for id 1.", courseById);
	}
	
	//test create course
	@Test
	public void testCreateCourse() {
		//when
		int newCourseId = 15;
		Course newCourse = new Course(newCourseId, "Math", "James Lyod");
		// During
		courseDAO.createCourse(newCourse);
		//get course by Id 15;
		Course newDBCourse = courseDAO.getCourseById(newCourseId);
		
		if(newDBCourse != null) {
			
			Assert.assertEquals(newCourse, newDBCourse);
		}
		else
			Assert.assertNull("No Course found for id 15.", newDBCourse);
		
	}
	
	//test update course method
	@Test
	public void testUpdateCourse() {
		//When
		int courseId = 14;
		String newCourseInstructor = "Kay Lin";
		//when
		Course course = courseDAO.getCourseById(courseId);
		//update course
		courseDAO.updateCourse(courseId, newCourseInstructor);
		//get updated course
		Course updatedCourse = courseDAO.getCourseById(courseId);
		
		if(updatedCourse != null) {
			
			Assert.assertEquals(course, updatedCourse);
		}
		else
			Assert.assertNull("No updated Course found for id 14.", updatedCourse);
		
	}
	
	//Test delete course
	@Test
	public void testDeleteCourse() {
		//when
		int courseId = 14;
		//During
		courseDAO.deleteCourse(courseId);
		//get the deleted course and check for null return
		Course deletedCourse = courseDAO.getCourseById(courseId);
		//Then
		Assert.assertTrue("Course with id = 14 has been deleted", deletedCourse == null);
	}
	
	

}
