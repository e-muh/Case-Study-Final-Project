package com.erasmusmuh.easylearn.casestudy.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erasmusmuh.easylearn.casestudy.dao.StudentDAO;
import com.erasmusmuh.easylearn.casestudy.entity.Student;

@Service
public class StudentServiceImpli implements StudentService {
	//add StudentDAO dependency
	@Autowired
	private StudentDAO studentDAO;
	
	@Override
	@Transactional
	public List<Student> getStudents() {
	
		return studentDAO.getAllStudents();
	}

	@Override
	@Transactional
	public Student getStudentById(String studentId) {
		
		return studentDAO.getStudentById(studentId);
	}


	@Override
	@Transactional
	public void registerCourse(String studentId, int courseId) {
		
		studentDAO.registerToCourse(studentId, courseId);

	}


	@Override
	@Transactional
	public void deleteStudentRegisteredCourse(String studentId, int courseId) {
		
		studentDAO.deleteStudentCourse(studentId, courseId);
		
	}

	@Override
	@Transactional
	public void createStudent(Student theStudent) {
		
		studentDAO.createStudent(theStudent);
		
	}

	@Override
	@Transactional
	public void updateStudent(String studentName, String studentEmail, String studentId) {
	
		studentDAO.updateStudent(studentName, studentEmail, studentId);
		
	}

	@Override
	@Transactional
	public void deleteStudent(String studentId) {

		studentDAO.deleteStudent(studentId);
		
	}

}
