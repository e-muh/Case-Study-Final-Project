package com.erasmusmuh.easylearn.casestudy.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.erasmusmuh.easylearn.casestudy.entity.User;
import com.erasmusmuh.easylearn.casestudy.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	
	//add userservice dependency
	@Autowired
	private UserService service;
	
	// resolve issue for our validation. initBinder for validation
	
	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
				
		StringTrimmerEditor stringTrimmerEditor = new StringTrimmerEditor(true);
				
		dataBinder.registerCustomEditor(String.class, stringTrimmerEditor);
		}
	
	//show easylearn homepage
	@GetMapping("/showHomePage")
	public String showHomePage() {
		return "homepage-form";
	}
	
	//show user login form
	@GetMapping("/showLoginForm")
	public String showLoginForm(Model model) {
		
		// create model attribute to bind form data
		User user = new User();
				
		model.addAttribute("theUser", user);
		
		return "login-form";
		
	}
	
	//show user registration form. same form to create user by admin
	@GetMapping("/showRegistrationForm")
	public String showRegistrationForm(Model model) {
		
		// create model attribute to bind form data
		User user = new User();
						
		model.addAttribute("theUser", user);
		
		return "registerUser-form";
		
	}
	
	//valadate or authenticate a user to display the appropriate dashboard
	@SuppressWarnings("unused")
	@PostMapping( "/validateUser" )
	public String validateUser( @RequestParam("userName") String uName, 
			@RequestParam("userPass") String uPass, @RequestParam("userType") String uType, Model model) {
		
		//get userbyName from service. check for null user with try-catch
		User user;
		
		try {
			user = service.getUserByName(uName);
		} catch (Exception e) {
			return "redirect:/user/showLoginForm";
		}
		
		boolean isStudent = user.getUserName().equals(uName) && user.getUserPass().equals(uPass) &&  user.getUserType().equalsIgnoreCase("student");
		boolean isTeacher = user.getUserName().equals(uName) && user.getUserPass().equals(uPass) && user.getUserType().equalsIgnoreCase("teacher");
		boolean isAdmin = user.getUserName().equals(uName) && user.getUserPass().equals(uPass) &&  user.getUserType().equalsIgnoreCase("admin");
		
		 if(isStudent) {
				// add student attribute
				model.addAttribute("student", user);
				
				// return student-dashboard-form
				return "student-dashboard";  
				}
				else if (isTeacher) {
					return "teacher-dashboard";
				}
				else if (isAdmin) {
					// add student attribute
					model.addAttribute("admin", user);
					//return admim dashboard
					return "admin-dashboard";
				}
				else
					return "redirect:/user/showLoginForm";
	}
	
	//list all users
	@GetMapping("/listUsers")
	public String listUsers(Model model){
		// get user from the service
		List<User> theUsers = service.getUsers();
				
		// add the user to the model
		model.addAttribute("users", theUsers);
				
		return "list-users-admin";
		
	}
	
	//save/create user method
	@PostMapping("/saveUser")
	public String saveUser(@Valid @ModelAttribute("theUser") User theUser, BindingResult result) {
		if(result.hasErrors()) {
			//return "redirect:/user/showRegistrationForm";
			return "registerUser-form";
		}
		else {
		// save the user using the service class
		service.addUser(theUser);
				
		//redirect to display updated list.
		return "redirect:/user/showLoginForm";
		}
	}

	//show user update form
	@GetMapping("/showUpdateForm")
	public String showUpdateForm(Model theModel) {
		
		//create user object model
		User user = new User();		
		// set user as a model attribute to pre-populate the form
		theModel.addAttribute("users", user);
				
		// send over to our form		
		return "user-update-form";
	}
	
	//admin userupdateform
	@GetMapping("/showUpdateFormAdmin")
	public String showUpdateFormAdmin(@RequestParam("userId") int uId, Model theModel) {
		// get the user from our service
		User user = service.getUserById(uId);	
				
		// set user as a model attribute to pre-populate the form
		theModel.addAttribute("users", user);
				
		// send over to our form		
		return "user-update-form-admin";
	}
	
	//use updateUser to change users login details by user
	@PostMapping("/updateUser")
	public String ChangeUserDetails(@ModelAttribute("users") User theUser) {
		
		String uPass = theUser.getUserPass();
		String uName = theUser.getUserName();
		//update user
		service.updateUser(uPass, uName);
		
		return "redirect:/user/showLoginForm";
		
	}
	
	//use updateUser to change users details by admin
		@PostMapping("/updateUserAdmin")
		public String ChangeUserDetailsAdmin(@ModelAttribute("users") User theUser) {
			
			String uPass = theUser.getUserPass();
			String uName = theUser.getUserName();
			//update user
			service.updateUser(uPass, uName);
			
			return "redirect:/user/listUsers";
			
		}
		
	// add this to admin previleges
	@GetMapping("/deleteUser")
	public String removeUser(@RequestParam("userId") int uId) {
		
		// delete the user
		service.deleteUser(uId);
				
		return "redirect:/user/listUsers";
		
	}
}
