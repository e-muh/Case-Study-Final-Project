package com.erasmusmuh.easylearn.casestudy.dao;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.erasmusmuh.easylearn.casestudy.entity.Course;
import com.erasmusmuh.easylearn.casestudy.entity.Student;

@Repository
public class StudentDAOImpli implements StudentDAO {
	// add SesssionFactory dependency
	@Autowired
	private SessionFactory factory;

	@Override
	public List<Student> getAllStudents() {
		// get the current hibernate session
		Session currentSession = null;
		try {
			currentSession = factory.getCurrentSession();
		} catch (HibernateException e) {
			currentSession = factory.openSession();
		}

		// create a query ... sort by last name
		Query<Student> theQuery = currentSession.createQuery("from Student", Student.class);

		// execute query and get result list
		List<Student> students = theQuery.getResultList();

		// return the results
		return students;
	}

	@Override
	public Student getStudentById(String studentId) {
		// get the current hibernate session
		Session session = factory.getCurrentSession();

		// now retrieve/read from database using the primary key
		Student student = session.get(Student.class, studentId);

		return student;
	}

	@Override
	public void registerToCourse(String studentId, int courseId) {
		// get the current hibernate session
		Session session = null;
		try {
			session = factory.getCurrentSession();
		} catch (HibernateException e) {
			session = factory.openSession();
		}

		// get student with studentId
		Student studente = session.get(Student.class, studentId);

		// get course with courseId,
		Course sCourse = session.get(Course.class, courseId);
		System.out.println(sCourse);

		// check if student is registered for course(studentCourses contains course), if
		// not, the add course to studentCourses.
		// add sCourse to the student set of courses. set doesnt accept duplicate, no
		// need to check if course is present in set
		studente.getStudentEnrolledCourses().add(sCourse);

	}

	// enable student to unenrol a course
	@Override
	public void deleteStudentCourse(String studentId, int courseId) {
		// get the current hibernate session
		Session session = factory.getCurrentSession();

		// get student with studentId
		Student student = session.get(Student.class, studentId);

		// get course with courseId,
		Course course = session.get(Course.class, courseId);

		if (course != null) {
			// remove course from studentcourses
			student.getStudentEnrolledCourses().remove(course);
		} else {
			System.out.println("Course does not exist.");

		}

	}

	@Override
	public void createStudent(Student theStudent) {

		// get the current hibernate session
		Session session = factory.getCurrentSession();
		// save theStudent to db
		session.save(theStudent);
	}

	@Override
	public void updateStudent(String studentName, String studentEmail, String studentId) {

		Session session = factory.getCurrentSession();

		@SuppressWarnings("rawtypes")
		Query query = session
				.createQuery("UPDATE Student SET studentName=:sName, studentEmail= :sEmail WHERE studentId= :sId");

		// set named parameter on query
		query.setParameter("sName", studentName);
		query.setParameter("sEmail", studentEmail);
		query.setParameter("sId", studentId);

		query.executeUpdate();

	}

	@Override
	public void deleteStudent(String studentId) {

		// get the current hibernate session
		Session session = factory.getCurrentSession();

		// delete object with primary key
		@SuppressWarnings("rawtypes")
		Query theQuery = session.createQuery("delete from Student where StudentId=:sId");
		// set named parameter on query
		theQuery.setParameter("sId", studentId);

		theQuery.executeUpdate();

	}

}
