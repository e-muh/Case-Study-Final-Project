package com.erasmusmuh.easylearn.casestudy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erasmusmuh.easylearn.casestudy.dao.CourseDAO;
import com.erasmusmuh.easylearn.casestudy.entity.Course;


@Service
public class CourseServiceImpli implements CourseService {
	
	//add CourseDAO dependency
	@Autowired
	private CourseDAO courseDAO;

	@Override
	@Transactional
	public List<Course> getCourses() {
		
		List<Course> myCourses = courseDAO.getAllCourses();
		
		return myCourses;
	}

	@Override
	@Transactional
	public Course getCourseById(int courseId) {
		
		return courseDAO.getCourseById(courseId);
	}

	@Override
	@Transactional
	public void updateCourse(int courseId, String courseInstructor) {
		
		courseDAO.updateCourse(courseId, courseInstructor);
		
	}

	@Override
	@Transactional
	public void deleteCourse(int courseId) {
		
		courseDAO.deleteCourse(courseId);
		
	}

	@Override
	@Transactional
	public void createCourse(Course course) {
		
		courseDAO.createCourse(course);
		
	}

	
}
