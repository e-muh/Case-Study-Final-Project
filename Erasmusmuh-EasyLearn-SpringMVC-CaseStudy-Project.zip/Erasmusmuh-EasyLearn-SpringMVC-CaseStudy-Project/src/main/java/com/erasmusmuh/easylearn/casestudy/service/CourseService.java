package com.erasmusmuh.easylearn.casestudy.service;

import java.util.List;

import com.erasmusmuh.easylearn.casestudy.entity.Course;

public interface CourseService {
	
	public List<Course> getCourses();
	
	public Course getCourseById(int courseId);
	
	//update courseInstructor
	public void updateCourse(int courseId, String courseInstructor);
	
	public void deleteCourse(int courseId);

	public void createCourse(Course course);


}
