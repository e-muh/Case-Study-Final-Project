package com.erasmusmuh.easylearn.casestudy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.erasmusmuh.easylearn.casestudy.entity.Course;
import com.erasmusmuh.easylearn.casestudy.service.CourseService;


@Controller
@RequestMapping("/course")
public class CourseController {
	//add courseService dependency
	@Autowired
	private CourseService courseService;
	
	//show admin dashboard
	@GetMapping("/showAdminDashboard")
	public String showAdminDashboard() {
		return "admin-dashboard";
	}
	
	//show create course input form
	@GetMapping("/showCreateCourseInput")
	public String showCreateCourseInput(Model model) { 
		//create a course object model
		Course theCourse = new Course();
		//add attribute to the course form
		model.addAttribute("course", theCourse);
		
		return "create-course-input";
	}
	
	//list courses on admin dashboard
	@GetMapping("/listCoursesAdmin")
	public String listCoursesAdmin(Model model){
		// get courses from the service
		List<Course> myCourses = courseService.getCourses();
				
		// add the courses to the model
		model.addAttribute("courses", myCourses);
				
		return "list-courses-admin";
		
	}
	
	//list a student registered courses
	@GetMapping("/listStudentCourses")
	public String listCourses(Model model){
		// get courses from the service
		List<Course> myCourses = courseService.getCourses();
				
		// add the courses to the model
		model.addAttribute("courses", myCourses);
				
		return "list-student-courses";
		
	}
	
	//create a course. Only available to admin
	@PostMapping("/saveCourse")
	public String saveCourse(@ModelAttribute("course") Course theCourse) {
		
		// save the user using the service class
		courseService.createCourse(theCourse);
				
		//redirect to display updated course list.
		return "redirect:/course/listCoursesAdmin";
		
	}
	
	//show course update form to admin
	@GetMapping("/showUpdateCourseForm")
	public String showUpdateForm(@RequestParam("courseId") int cId, Model theModel) {
		// get the course from our service
		Course theCourse = courseService.getCourseById(cId);	
				
		// set course as a model attribute to pre-populate the form
		theModel.addAttribute("course", theCourse);
				
		// send over to our form		
		return "course-update-form";
	}
	
	//update course method. use updatecourse to change courseInstructor Name
	@PostMapping("/updateCourse")
	public String ChangeCourseDetails(@RequestParam("courseId") int cId, @RequestParam("courseInstructor") String cInstructor) {
		//get parameters from the request
		//update course
		courseService.updateCourse(cId, cInstructor);
			
		return "redirect:/course/listCoursesAdmin";
			
		}
	
	//delete course method. Only available to admin previleges
	@GetMapping("/deleteCourse")
	public String removeCourse(@RequestParam("courseId") int cId) {
			
		// delete the course
		courseService.deleteCourse(cId);
		//redirect request to admins list courses endpoint			
		return "redirect:/course/listCoursesAdmin";
			
		}
}

