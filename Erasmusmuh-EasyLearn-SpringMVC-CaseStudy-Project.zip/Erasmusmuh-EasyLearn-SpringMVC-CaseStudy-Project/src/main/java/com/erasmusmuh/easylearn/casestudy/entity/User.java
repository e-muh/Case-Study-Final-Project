package com.erasmusmuh.easylearn.casestudy.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
@Table(name= "Users")
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;
	//userName, userPass and userType to maintain their default names on db table
	
	@NotEmpty(message = "required")
	@Size(min = 6, message = "must be six or more")
	private String userName;
	
	@NotEmpty(message = "field required. Should not be null or empty.")
	@Size(min = 6, message = "must be six or more")
	private String userPass;
	
	@NotNull(message = "required")
	private String userType;
	
	@NotBlank(message = "required")
	@Email(message = "should be a valid email")
	private String userEmail;
	
	//constructors
	public User() {}

	public User(String userName, String userPass, String userType, String userEmail) {
		super();
		this.userName = userName;
		this.userPass = userPass;
		this.userType = userType;
		this.userEmail = userEmail;
	}

	// getters and setters
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userPass=" + userPass + ", userType=" + userType
				+ ", userEmail=" + userEmail + "]";
	}
	
	
}
