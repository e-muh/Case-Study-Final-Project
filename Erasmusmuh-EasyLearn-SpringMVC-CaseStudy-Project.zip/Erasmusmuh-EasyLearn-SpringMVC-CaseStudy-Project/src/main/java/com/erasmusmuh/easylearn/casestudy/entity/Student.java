package com.erasmusmuh.easylearn.casestudy.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table (name= "student")
public class Student {
	
	@Id
	@Column(name= "studentId")
	private String studentId;
	
	@NotEmpty(message= "required")
	@Size(min=4, max= 20, message= "must be between 4 & 20.")
	@Column(name= "studentName")
	private String studentName;
	
	@NotBlank(message= "required")
	@Email(message= "must be a standard email.")
	@Column(name= "studentemail")
	private String studentEmail;
	
	
	@OneToMany(fetch = FetchType.EAGER, targetEntity = Course.class, cascade = CascadeType.ALL)
	private Set<Course> studentEnrolledCourses = new HashSet<>();
	
	//constructors
	public Student() {}
	
	
	public Student(String studentId, String studentName, String studentEmail) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentEmail = studentEmail;
	}


	public String getStudentId() {
		return studentId;
	}


	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}


	public String getStudentName() {
		return studentName;
	}


	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}


	public String getStudentEmail() {
		return studentEmail;
	}


	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}


	public Set<Course> getStudentEnrolledCourses() {
		return studentEnrolledCourses;
	}


	public void setStudentCourses(Set<Course> studentEnrolledCourses) {
		this.studentEnrolledCourses = studentEnrolledCourses;
	}


	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentEmail=" + studentEmail
				+ "]";
	}
	

}
