package com.erasmusmuh.easylearn.casestudy.dao;

import java.util.List;
import com.erasmusmuh.easylearn.casestudy.entity.Student;

public interface StudentDAO {
	
	public List<Student> getAllStudents();
	
	public Student getStudentById(String studentId);
	
	
	public void registerToCourse(String studentId, int courseId);
	
	
	//unregister a course
	public void deleteStudentCourse(String studentId, int courseId);

	public void createStudent(Student theStudent);

	public void updateStudent(String studentName, String studentEmail, String studentId);

	public void deleteStudent(String studentId);

}
