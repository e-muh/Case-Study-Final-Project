package com.erasmusmuh.easylearn.casestudy.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.erasmusmuh.easylearn.casestudy.entity.User;

@Repository 
public class UserDAOImpli implements UserDAO {
	
	@Autowired
	private SessionFactory factory;

	@Override
	public User getUserById(int userId) { 

		// get the current hibernate session
		Session session = factory.getCurrentSession();
				
		// now retrieve/read from database using the primary key
		User user = session.get(User.class, userId);
				
		return user;
	}

	@Override
	public List<User> getUsers() {
		
		// get the current hibernate session
		Session currentSession = factory.getCurrentSession();
						
		// create a query  ... sort by last name
		Query<User> theQuery = currentSession.createQuery("from User", User.class);
				
		// execute query and get result list
		List<User> users = theQuery.getResultList();
						
		// return the results		
		return users;
	}
	//The addUser() has dual role: to add a user and to Update a user from the service class
	@Override
	public void addUser(User user) {
		// get current hibernate session
		Session session = factory.getCurrentSession();
				
		// save the customer to db 
		session.save(user);

	}
	//updateUser() is used to change user login details
	@Override
	public void updateUser(String userPass, String userName) {

		Session session = factory.getCurrentSession();
		
		@SuppressWarnings("rawtypes")
		Query query = session.createQuery("UPDATE User SET userPass=:uPass WHERE userName= :uName");
		
		//set named parameter on query
		query.setParameter("uPass", userPass);
		query.setParameter("uName", userName);
				
		query.executeUpdate();
		

	}

	@Override
	public void deleteUser(int userId) {
		// get the current hibernate session
		Session session = factory.getCurrentSession();
				
		// delete object with primary key
		@SuppressWarnings("rawtypes")
		Query theQuery = session.createQuery("delete from User where userId=:uId");
		//set named parameter on query
		theQuery.setParameter("uId", userId);
				
		theQuery.executeUpdate();
		
	}

	@Override
	public User getUserByName(String userName) {
		Session session = factory.getCurrentSession();
		
		@SuppressWarnings("rawtypes")
		Query theQuery = session.createQuery("from User where userName=:uName");
		//set named parameter on query
		theQuery.setParameter("uName", userName);
		
		User result = (User) theQuery.getSingleResult();
		
		return result;
	}

}
