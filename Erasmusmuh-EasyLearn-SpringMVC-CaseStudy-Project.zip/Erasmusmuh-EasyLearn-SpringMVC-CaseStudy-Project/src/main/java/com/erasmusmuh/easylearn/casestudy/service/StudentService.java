package com.erasmusmuh.easylearn.casestudy.service;

import java.util.List;
import com.erasmusmuh.easylearn.casestudy.entity.Student;

public interface StudentService {
	
	public List<Student> getStudents();
	
	public Student getStudentById(String studentId);
	
	
	public void registerCourse(String studentId, int courseId);
	
	
	public void deleteStudentRegisteredCourse(String studentId, int courseId);

	public void createStudent(Student theStudent);

	public void updateStudent(String studentName, String studentEmail, String studentId);

	public void deleteStudent(String studentId); 
	

}
