package com.erasmusmuh.easylearn.casestudy.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.erasmusmuh.easylearn.casestudy.entity.Course;

@Repository
public class CourseDAOImpli implements CourseDAO {
	
	//add SessionFactory dependency
	@Autowired
	private SessionFactory factory;
	

	@Override
	public List<Course> getAllCourses() {

		// get the current hibernate session
		Session currentSession = factory.getCurrentSession();
						
		// create a query  ... sort by last name
		Query<Course> theQuery = currentSession.createQuery("from Course", Course.class);
				
		// execute query and get result list
		List<Course> myCourses = theQuery.getResultList();
						
		// return the results		
		return myCourses;
	}

	@Override
	public Course getCourseById(int courseId) {
		// get the current hibernate session
		Session session = factory.getCurrentSession();
						
		// now retrieve/read from database using the primary key
		Course course = session.get(Course.class, courseId);
						
		return course;
	}

	@Override
	public void createCourse(Course course) {
		// get current hibernate session
		Session session = factory.getCurrentSession();
				
		// save the customer to db 
		session.save(course);
	}

	@Override
	public void updateCourse(int courseId, String courseInstructor) {
	Session session = factory.getCurrentSession();
		
		@SuppressWarnings("rawtypes")
		Query query = session.createQuery("UPDATE Course SET courseInstructor=:cInstructor WHERE courseId= :cId");
		
		//set named parameter on query
		query.setParameter("cInstructor", courseInstructor);
		query.setParameter("cId", courseId);
				
		query.executeUpdate();

	}

	@Override
	public void deleteCourse(int courseId) {
		// get the current hibernate session
		Session session = factory.getCurrentSession();
						
		// delete object with primary key
		@SuppressWarnings("rawtypes")
		Query theQuery = session.createQuery("delete from Course where courseId=:cId");
		//set named parameter on query
		theQuery.setParameter("cId", courseId);
						
		theQuery.executeUpdate();
	}

}
