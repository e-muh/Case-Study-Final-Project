package com.erasmusmuh.easylearn.casestudy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erasmusmuh.easylearn.casestudy.dao.UserDAO;
import com.erasmusmuh.easylearn.casestudy.entity.User;


@Service
public class UserServiceImpli implements UserService {
	
	@Autowired
	private UserDAO userDAO;

	//@Transactional annotation on each service method indicates a spring hibernate transaction process
	
	@Override
	@Transactional
	public User getUserById(int userId) { 
		
		return userDAO.getUserById(userId);
	}

	@Override
	@Transactional
	public List<User> getUsers() {
		
		return userDAO.getUsers();
	}

	@Override
	@Transactional
	public void addUser(User user) {

		userDAO.addUser(user);

	}

	@Override
	@Transactional
	public void updateUser(String userPass, String userName) {
		
		userDAO.updateUser(userPass, userName);

	}

	@Override
	@Transactional
	public void deleteUser(int userId) { 

		userDAO.deleteUser(userId);

	}

	@Override
	@Transactional
	public User getUserByName(String userName) {
		
		return userDAO.getUserByName(userName);
	}

}
