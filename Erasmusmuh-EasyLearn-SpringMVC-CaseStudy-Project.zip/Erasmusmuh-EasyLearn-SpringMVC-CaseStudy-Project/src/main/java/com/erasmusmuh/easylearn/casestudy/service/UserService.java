package com.erasmusmuh.easylearn.casestudy.service;

import java.util.List;

import com.erasmusmuh.easylearn.casestudy.entity.User;

public interface UserService {
	
	public User getUserById(int userId);
	
	public List<User> getUsers();
	
	public void addUser(User user);
	
	//use updateUser to change users login details
	public void updateUser(String userPass, String userName);

	public void deleteUser(int userId);
	
	public User getUserByName(String userName);

}
