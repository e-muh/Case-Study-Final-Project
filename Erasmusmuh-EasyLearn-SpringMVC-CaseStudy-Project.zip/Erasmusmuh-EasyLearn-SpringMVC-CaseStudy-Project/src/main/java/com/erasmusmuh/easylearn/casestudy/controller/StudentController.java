package com.erasmusmuh.easylearn.casestudy.controller;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.erasmusmuh.easylearn.casestudy.entity.Course;
import com.erasmusmuh.easylearn.casestudy.entity.Student;
import com.erasmusmuh.easylearn.casestudy.service.CourseService;
import com.erasmusmuh.easylearn.casestudy.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {
//this class controls how student listAllCourses, listRegisterdCourses, registerCourse
	
	//add dependencies
	@Autowired
	private StudentService studentService;
	
	@Autowired
	private CourseService courseService;
	
	// initBinder for form validation
	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
				
		StringTrimmerEditor stringTrimmerEditor = new StringTrimmerEditor(true);
				
		dataBinder.registerCustomEditor(String.class, stringTrimmerEditor);
		}
	
	//show student dashboard
	@GetMapping("/showStudentDashboard")
	public String showStudentDashboard() {
		return "student-dashboard";
	    }
	
	//show create student form
	@GetMapping("/showCreateStudentInput")
	public String showCreateStudentInput( Model model) { 
		//create student model
		Student stud = new Student();
		
		//add stud to model attribute, to store on form
		model.addAttribute("student", stud);
		
		return "create-student-input";
	}
	
	//list all courses
	@GetMapping("/listCourses")
	public String listCourses(Model model){
		// get courses from the service
		List<Course> myCourses = courseService.getCourses();
				
		// add the courses to the model
		model.addAttribute("courses", myCourses);
				
		return "list-courses-and-registered-courses";
		
	}
	
	//show register user form
	@GetMapping("/showRegisterCourseInput")
	public String showRegisterCourseInput() { 
		
		return "register-course-input";
	}
	
	//register course with studentId and courseId parameter from the request query string
	@GetMapping("/registerCourse")
	public String registerCourse(HttpServletRequest request, HttpServletResponse response) {
		String studentId = request.getParameter("studentId");
		//parse sting input to int
		int courseId = Integer.parseInt(request.getParameter("courseId"));
		
		studentService.registerCourse(studentId, courseId);
		
		return "redirect:/student/listCourses";
	}
	
	//show check my courses input form
	@GetMapping("/showCheckMyCourseInput")
	public String showCheckMyCourseInput() { 
		
		return "check-courses-input";
	}
	
	//list student registered courses
	@GetMapping("/listStudentRegisterCourses")
	public String listStudentCourses(HttpServletRequest request, HttpServletResponse response, Model model){
		
		//get studentId from httpServlet request query string
		String studentId = request.getParameter("studentId");
		// get courses from the service
		Student student = studentService.getStudentById(studentId);
		//getStudent enrolled courses
		Set<Course> sCourses = student.getStudentEnrolledCourses();
				
		// add the courses to the model
		model.addAttribute("registeredCourses", sCourses);
				
		return "list-my-registered-courses";
		
	}
	
	//show unenroll course form
	@GetMapping("/showUnenrolCourseInput")
	public String showUnenrolCourseInput() { 
		
		return "unenrol-course-input";
	}
	
	//unregister course methos
	@GetMapping("/removeRegisteredCourse")
	public String removeStudentCourse(HttpServletRequest request, HttpServletResponse response) {
		
		String studentId = request.getParameter("studentId");
		
		int courseId = Integer.parseInt(request.getParameter("courseId"));
		
		studentService.deleteStudentRegisteredCourse(studentId, courseId);
		
		//return to student dashboard
		return "student-dashboard";
		
	}
	
	//save student method
	@PostMapping("/saveStudent")
	public String saveCourse(@Valid @ModelAttribute("student") Student theStudent, BindingResult result) {
		
		if(result.hasErrors()) {
			return "create-student-input";
		}
		else {
		// save the student using the service class
		studentService.createStudent(theStudent);
				
		//redirect to display updated student list.
		return "redirect:/student/listStudentsAdmin";
		}
	}
	
	//list student on admin dashboard
	@GetMapping("/listStudentsAdmin")
	public String listStudents(Model model){
		// get students from the service
		List<Student> myStudents = studentService.getStudents();
				
		// add the students to the model
		model.addAttribute("students", myStudents);
				
		return "list-students-admin";
		
	}
	
	//show update student form
	@GetMapping("/showUpdateStudentForm")
	public String showUpdateForm(@RequestParam("studentId") String sId, Model theModel) {
		// get the student from our service
		Student theStudent = studentService.getStudentById(sId);	
				
		// set student as a model attribute to pre-populate the form
		theModel.addAttribute("student", theStudent);
				
		// send over to our form		
		return "update-student-form";
	}

	//use updatestudent to change student Name and email
	@PostMapping("/updateStudent")
	public String ChangeStudentDetails(@RequestParam("studentName") String sName, @RequestParam("studentEmail") String sEmail,
			@RequestParam("studentId") String sId) {
			
			//update course
			studentService.updateStudent(sName, sEmail, sId);
				
			return "redirect:/student/listStudentsAdmin";
				
			}
	
	// add this to admin previleges
		@GetMapping("/deleteStudent")
		public String removeCourse(@RequestParam("studentId") String sId) {
				
			// delete the student
			studentService.deleteStudent(sId);
			//redirect request to admins list student endpoint			
			return "redirect:/student/listStudentsAdmin";
				
			}
		
		//show iframe
		@GetMapping("/showIframe")
		public String showIframe() {
			return "view-iframe";
		}
}
