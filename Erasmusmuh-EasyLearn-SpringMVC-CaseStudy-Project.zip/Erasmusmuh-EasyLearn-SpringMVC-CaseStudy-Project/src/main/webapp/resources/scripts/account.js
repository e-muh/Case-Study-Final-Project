const form = document.getElementById("form");
const userName = document.getElementById("username");
const email = document.getElementById("email");
const password = document.getElementById("password");
const password2 = document.getElementById("password2");

//add eventlisterner
form.addEventListener("submit", (e) => {
   //prevent default submission
    e.preventDefault();
    //validate input
    if (checkInputs()){
    //opens new page on successful validation and form submission
        successLogin();
    }
 
});


function checkInputs(){
    //get values from the inputs
    const userNameValue = userName.value.trim();    //trim() removes any whitespaces the user might have entered
    const emailValue = email.value;
    const passwordValue = password.value;
    const password2Value = password2.value;
//check username
    if(userNameValue ===""){ //check if usernamevalue is empty
        //show error
        setErrorFor(userName, "Username cannot be blank");
    }
    else if(userNameValue.length <= 4){
        setErrorFor(userName, "Name length must be greater than 4 characters")
    }
    else{
        //add success message
        setSuccessFor(userName);
    }
//check email
    if(emailValue ===""){ //check if emailvalue is empty
        //show error
        setErrorFor(email, "Email cannot be blank");
    }
     //check if email is valid
    else if(!isEmail(emailValue)){
       //show error
        setErrorFor(email, "Not a valid Email");
    }
    else{
        //show success
        setSuccessFor(email);
    }
//check paassword
    if(passwordValue ===""){ //check if usernamevalue is empty
        
        setErrorFor(password, "Password cannot be blank");
    }
    //further check password with regexp and length. add 2 else if and two methods
    //var plength =  passwordValue.length;
    else if(passwordValue.length < 6 || passwordValue.length > 18){
        setErrorFor(password, "Password length must be between 6 and 18.");
    }
    else{
        //show success 
        setSuccessFor(password);
    }
//check paassword2
    if(password2Value ===""){ //check if usernamevalue is empty
        
        setErrorFor(password2, "Password cannot be blank");
    }
    else if(passwordValue != password2Value){
        setErrorFor(password2, "Password does not match");
    }
    else{
        //show success 
        setSuccessFor(password2);
    }

    //validity condition
    var isPassword = passwordValue.length >= 6 && passwordValue.length <= 18;
    if(userNameValue.length >=4 && isEmail(emailValue) && isPassword){
        alert("Login successfully validated!");
        return true;
    }
    else{
        return false;
    }

}

function setErrorFor(input, message){
    //move from child to parent, to get parent class
    const formControl = input.parentElement; //.form_control. Error class will be added here, parent to small tag
    var small = formControl.querySelector("small");
    //make message in small tag visible
  // small.style.visibility = "visible";
    //add error message inside small tag
    small.innerText = message;
    //add error to classlist// classname// add error class
    //formControl.className = "form_control error";
    formControl.classList.add("error");
}
function setSuccessFor(input){
    const formControl = input.parentElement; //.form_control
    //add classname
    formControl.className = "form_control success";
    //formControl.classList.add("success");
}
//check email with regexp
function isEmail(email){
var regx = new RegExp(/^([a-zA-Z0-9\._]+)@([a-zA-Z0-9])+.([a-z]+)(.[a-z]+)?$/);
  return regx.test(email);
    
}

//function to display success message in new html page when form submitted.
function successLogin() {
    location.href = "saveUser";
}
